This is a set of patches created by the community to bring KW up to 1.0.4 
compatibility.

This consists of two files.  The first file is KWPatch.cfg, which consists of 
all the safe patches created.

The second is KWPatch-interstage.cfg.  This file switches the interstage 
fairings over to omni decouplers and removes the finicky extra node on 
engines/shrouds. This is convceivably craft breaking so it might be 
best to leave it as an optional module.

If you don't want the second patch, then either delete it or rename it.
