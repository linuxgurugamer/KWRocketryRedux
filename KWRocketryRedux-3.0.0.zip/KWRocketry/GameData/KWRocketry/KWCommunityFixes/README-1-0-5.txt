This is a supplemental patch to the existing KWCommunity patches.

Simply put the .cfg file into the same directory as the other patches:

GameData/KWCommunityFixes
